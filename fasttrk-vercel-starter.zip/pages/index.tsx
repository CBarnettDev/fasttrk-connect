export default function Home() {
  return (
    <main style={{ padding: 50 }}>
      <h1>🚀 Fasttrk AI Voice Bot Dashboard</h1>
      <p>Live. Connected. Fast.</p>
    </main>
  );
}